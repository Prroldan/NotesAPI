package com.e.notesapp.retrofit

class ListadoNotasResponse : ArrayList<Nota>()