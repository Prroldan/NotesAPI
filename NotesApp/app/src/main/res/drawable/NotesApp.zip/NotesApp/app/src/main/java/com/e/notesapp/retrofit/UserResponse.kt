package com.e.notesapp.retrofit

data class UserResponse(
    val fullName: String,
    val id: String,
    val roles: String,
    val username: String
)