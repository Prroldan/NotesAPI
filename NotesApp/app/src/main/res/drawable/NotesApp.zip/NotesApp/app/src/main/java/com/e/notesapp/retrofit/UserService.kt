package com.e.notesapp.retrofit

import retrofit2.Call
import retrofit2.http.POST

interface UserService {

    @POST("/auth/login")
    fun login(): Call<UserRequest>
}