package com.e.notesapp.retrofit

data class UserRequest (
    val username:String,
    val password:String
)