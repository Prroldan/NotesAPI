package com.e.notesapp.common

class Constantes {
    companion object {
        val SHARED_PREFS_FILE: String? = "SHARED_PREFERENCES_FILE"
        val TIMEOUT_INMILIS = 30000L
        val BASE_URL = "https://localhost:9000"
        val URL_PARAM_API_KEY = "api_key"
        val URL_PARAM_LANGUAGE = "language"
    }
}